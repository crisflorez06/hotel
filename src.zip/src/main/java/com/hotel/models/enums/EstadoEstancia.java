package com.hotel.models.enums;

public enum EstadoEstancia {
    RESERVADA,
    ACTIVA,
    FINALIZADA,
    EXCEDIDA
}
