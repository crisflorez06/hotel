package com.hotel.services;

import com.hotel.dtos.EstanciaDTO;
import com.hotel.dtos.EstanciaEditarRequestDTO;
import com.hotel.dtos.EstanciaNuevoRequestDTO;
import com.hotel.mappers.EstanciaMapper;
import com.hotel.models.*;
import com.hotel.models.enums.EstadoEstancia;
import com.hotel.models.enums.EstadoOperativo;
import com.hotel.models.enums.ModoOcupacion;
import com.hotel.models.enums.TipoOcupante;
import com.hotel.models.enums.TipoUnidad;
import com.hotel.repositories.EstanciaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class EstanciaService {

    private static final Logger logger = LoggerFactory.getLogger(EstanciaService.class);

    private final EstanciaRepository estanciaRepository;
    private final OcupanteService ocupanteService;
    private final HabitacionService habitacionService;
    private final EstanciaHabitacionService estanciaHabitacionService;
    private final PagoService pagoService;
    private final UnidadService unidadService;


    public EstanciaService(EstanciaRepository estanciaRepository,
                           OcupanteService ocupanteService,
                           HabitacionService habitacionService,
                           EstanciaHabitacionService estanciaHabitacionService,
                           PagoService pagoService,
                           UnidadService unidadService) {
        this.estanciaRepository = estanciaRepository;
        this.ocupanteService = ocupanteService;
        this.habitacionService = habitacionService;
        this.estanciaHabitacionService = estanciaHabitacionService;
        this.pagoService = pagoService;
        this.unidadService = unidadService;
    }

    @Transactional
    public Estancia crearEstancia(EstanciaNuevoRequestDTO request) {

        logger.info("[crearEstancia] Verificando disponibilidad para la unidad o habitacion con codigo: {}", request.getCodigo());
        validarDisponibilidad(request);

        logger.info("[crearEstancia] Validando fechas de entrada y salida de la estancia");
        validarFechas(request.getEntradaReal(), request.getSalidaEstimada());

        logger.info("[crearEstancia] Mapeando datos del request a la entidad Estancia");
        Estancia estancia = EstanciaMapper.requestNuevoToEntity(request);

        logger.info("[crearEstancia] Cargando ocupantes para la estancia");
        estancia.setOcupantes(construirOcupantes(request.getIdCliente(), request.getIdAcompanantes()));

        logger.info("[crearEstancia] Llenando habitaciones asociadas a la estancia");
        estancia.setEstanciaHabitaciones(estanciaHabitacionService.llenarHabitaciones(estancia, request.getCodigo(), request.getTipoUnidad()));

        logger.info("[crearEstancia] Estableciendo modo de ocupacion para la estancia");
        estancia.setModoOcupacion(determinarModoOcupacion(request.getTipoUnidad()));

        logger.info("[crearEstancia] Cambiando estado de las habitaciones asociadas a la estancia a OCUPADO");
        actualizarEstadoInicial(estancia, request);
        logger.info("[crearEstancia] Guardando estancia en la base de datos");
        Estancia estanciaGuardada = estanciaRepository.save(estancia);

        if(request.getPago() != null) {
            logger.info("Registrando pago asociado a la estancia");
            Pago pago = pagoService.crearPago(request.getPago(), estanciaGuardada.getId());
            estanciaGuardada.setPago(pago);
        }

        return estanciaGuardada;
    }

    @Transactional
    public Estancia editarEstancia(EstanciaEditarRequestDTO request, Long idEstancia) {
        logger.info("Editando estancia con id: {}", idEstancia);
        Estancia estancia = buscarPorId(idEstancia);

        LocalDateTime nuevaEntrada = request.getEntradaReal() != null ? request.getEntradaReal() : estancia.getEntradaReal();
        LocalDateTime nuevaSalida = request.getSalidaEstimada() != null ? request.getSalidaEstimada() : estancia.getSalidaEstimada();
        validarFechas(nuevaEntrada, nuevaSalida);

        actualizarOcupantes(estancia, request);

        if (request.getEntradaReal() != null) {
            logger.info("Actualizando entrada real de la estancia");
            estancia.setEntradaReal(request.getEntradaReal());
        }

        if (request.getSalidaEstimada() != null) {
            logger.info("Actualizando salida estimada de la estancia");
            estancia.setSalidaEstimada(request.getSalidaEstimada());
        }

        if (request.getNotas() != null) {
            logger.info("Actualizando notas de la estancia");
            estancia.setNotas(concatenarNotas(estancia.getNotas(), request.getNotas()));
        }

        return estanciaRepository.save(estancia);
    }

    @Transactional
    public Void eliminarEstancia(Long idEstancia) {
        logger.info("Eliminando estancia con id: {}", idEstancia);
        Estancia estancia = buscarPorId(idEstancia);

        if (estancia.getEstanciaHabitaciones().isEmpty()) {
            throw new IllegalStateException("La estancia no tiene habitaciones asociadas.");
        }

        String codigoUnidad = estancia.getEstanciaHabitaciones().getFirst().getHabitacion().getUnidad().getCodigo();
        TipoUnidad tipoUnidad = estancia.getEstanciaHabitaciones().getFirst().getHabitacion().getUnidad().getTipo();

        pagoService.eliminarPagoPorEstancia(estancia.getId());
        habitacionService.cambiarEstadoHabitaciones(codigoUnidad, EstadoOperativo.DISPONIBLE , tipoUnidad);
        estanciaHabitacionService.vaciarHabitaciones(estancia);

        estancia.setPago(null);
        estancia.setActivo(false);
        estancia.setEstado(EstadoEstancia.FINALIZADA);
        estanciaRepository.save(estancia);
        return null;
    }

    public EstanciaDTO obtenerEstancia(String codigo, TipoUnidad tipoUnidad) {
        logger.info("[obtenerEstanciaPorUnidad] Obteniendo estancia para la unidad con codigo: {}", codigo);

        Long idHabitacion = resolverIdHabitacion(codigo, tipoUnidad);
        Estancia estancia = obtenerEstanciaPorHabitacion(idHabitacion);

        return EstanciaMapper.entityToDTO(estancia);
    }

    private Estancia obtenerEstanciaPorHabitacion(Long idHabitacion) {
        logger.info("[obtenerEstanciaPorHabitacion] Obteniendo estancia para la habitacion con id: {}", idHabitacion);
        return estanciaHabitacionService.obtenerEstanciaActivaPorHabitacionId(idHabitacion);
    }

    private ModoOcupacion determinarModoOcupacion(TipoUnidad tipoUnidad) {

        return tipoUnidad == TipoUnidad.HABITACION ? ModoOcupacion.INDIVIDUAL : ModoOcupacion.COMPLETO;
    }


    private Estancia buscarPorId(Long idEstancia) {
        return estanciaRepository.findById(idEstancia)
                .orElseThrow(() -> new IllegalArgumentException("Estancia no encontrada con id: " + idEstancia));
    }

    private void validarDisponibilidad(EstanciaNuevoRequestDTO request) {
        if (!habitacionService.verificarDisponiblidad(request.getCodigo(), request.getTipoUnidad())) {
            throw new IllegalStateException("La unidad o habitacion no está disponible para la estancia.");
        }
    }

    private void validarFechas(LocalDateTime entradaReal, LocalDateTime salidaEstimada) {
        if (salidaEstimada.isBefore(entradaReal)) {
            throw new IllegalArgumentException("salida estimada debe ser posterior a entrada real");
        }
    }

    private void actualizarEstadoInicial(Estancia estancia, EstanciaNuevoRequestDTO request) {
        LocalDateTime ahora = LocalDateTime.now();
        if (!estancia.getEntradaReal().isAfter(ahora)) {
            estancia.setEstado(EstadoEstancia.ACTIVA);
            habitacionService.cambiarEstadoHabitaciones(request.getCodigo(), EstadoOperativo.OCUPADO, request.getTipoUnidad());
        } else {
            estancia.setEstado(EstadoEstancia.RESERVADA);
        }
    }

    private List<Ocupante> construirOcupantes(Long idCliente, List<Long> idsAcompanantes) {
        if (idCliente == null) {
            throw new IllegalArgumentException("El cliente es obligatorio para crear la estancia.");
        }

        List<Ocupante> ocupantes = new ArrayList<>();
        ocupantes.add(obtenerOcupanteConTipo(idCliente, TipoOcupante.CLIENTE));
        ocupantes.addAll(obtenerOcupantesConTipo(idsAcompanantes, TipoOcupante.ACOMPANANTE));
        return ocupantes;
    }

    private void actualizarOcupantes(Estancia estancia, EstanciaEditarRequestDTO request) {
        if (request.getIdCliente() == null && request.getIdAcompanantes() == null) {
            return;
        }

        List<Ocupante> ocupantesActuales = new ArrayList<>(estancia.getOcupantes());

        if (request.getIdCliente() != null) {
            logger.info("Actualizando ocupante titular de la estancia");
            Ocupante titular = obtenerOcupanteConTipo(request.getIdCliente(), TipoOcupante.CLIENTE);
            ocupantesActuales = reemplazarTitular(ocupantesActuales, titular);
        }

        if (request.getIdAcompanantes() != null) {
            logger.info("Agregando ocupantes adicionales a la estancia");
            List<Ocupante> nuevosAcompanantes = obtenerOcupantesConTipo(request.getIdAcompanantes(), TipoOcupante.ACOMPANANTE);
            ocupantesActuales = agregarAcompanantes(ocupantesActuales, nuevosAcompanantes);
        }

        estancia.setOcupantes(ocupantesActuales);
    }

    private Ocupante obtenerOcupanteConTipo(Long idOcupante, TipoOcupante tipoEsperado) {
        Ocupante ocupante = ocupanteService.buscarPorId(idOcupante);
        if (ocupante.getTipoOcupante() != tipoEsperado) {
            return ocupanteService.crearOcupanteConDiferenteTipo(ocupante, tipoEsperado);
        }
        return ocupante;
    }

    private List<Ocupante> obtenerOcupantesConTipo(List<Long> idsOcupantes, TipoOcupante tipoEsperado) {
        List<Ocupante> resultado = new ArrayList<>();
        if (idsOcupantes == null) {
            return resultado;
        }

        for (Long id : idsOcupantes) {
            resultado.add(obtenerOcupanteConTipo(id, tipoEsperado));
        }

        return resultado;
    }

    private List<Ocupante> reemplazarTitular(List<Ocupante> ocupantesActuales, Ocupante titular) {
        List<Ocupante> resultado = new ArrayList<>();
        boolean reemplazado = false;

        for (Ocupante ocupante : ocupantesActuales) {
            if (ocupante.getTipoOcupante() == TipoOcupante.CLIENTE) {
                if (!reemplazado) {
                    resultado.add(titular);
                    reemplazado = true;
                }
                continue;
            }
            resultado.add(ocupante);
        }

        if (!reemplazado) {
            resultado.add(titular);
        }

        return resultado;
    }

    private List<Ocupante> agregarAcompanantes(List<Ocupante> ocupantesActuales, List<Ocupante> nuevosAcompanantes) {
        Set<Long> idsActuales = new HashSet<>();
        for (Ocupante ocupante : ocupantesActuales) {
            if (ocupante.getId() != null) {
                idsActuales.add(ocupante.getId());
            }
        }

        for (Ocupante ocupante : nuevosAcompanantes) {
            Long id = ocupante.getId();
            if (id == null || !idsActuales.contains(id)) {
                ocupantesActuales.add(ocupante);
                if (id != null) {
                    idsActuales.add(id);
                }
            }
        }

        return ocupantesActuales;
    }

    private String concatenarNotas(String notasActuales, String nuevasNotas) {
        String nuevasLimpias = nuevasNotas == null ? "" : nuevasNotas.trim();
        if (nuevasLimpias.isEmpty()) {
            return notasActuales;
        }
        if (notasActuales == null || notasActuales.isBlank()) {
            return nuevasLimpias;
        }
        return notasActuales + " | Notas editadas: " + nuevasLimpias;
    }

    private Long resolverIdHabitacion(String codigo, TipoUnidad tipoUnidad) {
        if (tipoUnidad == TipoUnidad.HABITACION) {
            logger.info("[obtenerEstanciaPorUnidad] Buscando estancia por habitacion");
            Habitacion habitacion = habitacionService.buscarPorCodigo(codigo);
            return habitacion.getId();
        }

        Unidad unidad = unidadService.buscarPorCodigo(codigo);
        if (unidad.getHabitaciones().isEmpty()) {
            throw new IllegalStateException("La unidad no tiene habitaciones asociadas.");
        }
        String codigoHabitacion = unidad.getHabitaciones().getFirst().getCodigo();
        logger.info("[obtenerEstanciaPorUnidad] Buscando estancia por habitacion asociada a la unidad, codigoHabitacion: {}", codigoHabitacion);
        Habitacion habitacion = habitacionService.buscarPorCodigo(codigoHabitacion);
        return habitacion.getId();
    }


}
